import sys

sys.stdin = open("반복문자input.txt")

total_tc = int(input())

for tc in range(1, total_tc):
