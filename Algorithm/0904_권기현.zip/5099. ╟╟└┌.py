import sys
sys.stdin = open("5099.txt")


